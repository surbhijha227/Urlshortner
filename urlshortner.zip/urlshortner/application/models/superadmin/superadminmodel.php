<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class superadminmodel extends CI_Model 
{

public function shortURL($longurl)
{
	$crt_date = date('Y-m-d H:i:s');
	$data = array(
				   "longUrl"=>$longurl
				 );
	$data_string = json_encode($data);

	$url_value = curl_init('https://www.googleapis.com/urlshortener/v1/url?key=AIzaSyBImkKgvPnI0Jk3z3azCEo5vdl0SU_mBt4');                                                                      
    curl_setopt($url_value, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
	curl_setopt($url_value, CURLOPT_POSTFIELDS, $data_string);                                                                  
	curl_setopt($url_value, CURLOPT_RETURNTRANSFER, true);                                                                      
	curl_setopt($url_value, CURLOPT_SSL_VERIFYPEER, false);                                                                      
	curl_setopt($url_value, CURLOPT_HTTPHEADER, array(                                                                          
  		'Content-Type: application/json',                                                                                
    	'Content-Length: ' . strlen($data_string),
    	
    	)                                                                       
	);

	  $result = curl_exec($url_value);
    $parse_result= json_decode($result,true);
    $short_url = $parse_result['id'];
    curl_close($url_value);

    $insert = array(
    				"long_url"  =>$longurl,
    				"short_url" =>$short_url,
    				"crt_date"  =>$crt_date
    			   );
       //echo '<pre>';print_r($insert);die;
  		$this->db->insert("shorted_url",$insert);
  		$final_result = $this->db->trans_complete();
  		return $short_url;
}

public function getAllURL()
{
	$query = $this->db->query("SELECT * FROM shorted_url");
	return $query->result();
}

}