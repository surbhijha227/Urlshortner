<?php

class superadmin extends CI_Controller{
	
	public function __construct(){ // contructor is used to run default functions
		parent::__construct();
		
		
		$this->load->model('superadmin/superadminmodel');
	}
	
	
	public function dashboard()
	{

		$this->load->view('superadmin/header');
		$this->load->view('superadmin/side_menu');
		$data['record'] = $this->superadminmodel->getAllURL();

		$this->load->view('superadmin/form',$data);
	}

	public function convertURL()
	{
		$longurl = $this->input->post('long_url');
		$upload_result = $this->superadminmodel->shortURL($longurl);
		 echo $upload_result;
	}

	public function getAllDataAjax()
	{
       
        $data = $this->superadminmodel->getAllURL();
        $i=1;
        foreach($data as $row)
        {
        	?>
              
                  <tr class="odd gradeX">
                  <td><?php echo $i++;?></td>
                  <td><?php echo $row->long_url;?></td>
                  <td class="center"><?php echo $row->short_url;?></td>
                  <td class="center"><?php echo $row->crt_date;?></td>
                 </tr>

        <?php	
        }
	}

}	