<!--sidebar-menu-->
<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="active"><a href="<?php echo base_url(); ?>dashboard"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
    
  </ul>
</div>
<!--sidebar-menu-->