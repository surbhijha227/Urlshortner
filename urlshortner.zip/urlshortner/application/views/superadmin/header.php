<!DOCTYPE html>
<html lang="en">
<head>
<title>Test</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="<?php echo base_url();?>assets/superadmin/css/bootstrap.min.css" />
<link rel="stylesheet" href="<?php echo base_url();?>assets/superadmin/css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="<?php echo base_url();?>assets/superadmin/css/fullcalendar.css" />
<link rel="stylesheet" href="<?php echo base_url();?>assets/superadmin/css/matrix-style.css" />
<link rel="stylesheet" href="<?php echo base_url();?>assets/superadmin/css/matrix-media.css" />
<link href="<?php echo base_url();?>assets/superadmin/font-awesome/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo base_url();?>assets/superadmin/css/jquery.gritter.css" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
<!--Header-part-->
<div id="header">
  <h1><a href="">Test</a></h1>
</div>
<!--close-Header-part--> 